const Router = require('restify-router').Router;
const router = new Router();

router.get('/:name', (req, res, next) => {
    res.send(req.params);
    return next();
});

module.exports = router;
