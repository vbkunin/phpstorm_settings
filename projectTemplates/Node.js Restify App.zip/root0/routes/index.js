const Router = require('restify-router').Router;
const router = new Router();

router.get('/', (req, res, next) => {
    res.send('Hello, world!');
    return next();
});

module.exports = router;
