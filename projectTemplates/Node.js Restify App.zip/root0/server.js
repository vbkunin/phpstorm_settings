const restify = require('restify');

const server = restify.createServer({
    name: 'node-restify-app',
    version: '1.0.0'
});

server.use(restify.plugins.acceptParser(server.acceptable));
server.use(restify.plugins.queryParser());
server.use(restify.plugins.bodyParser());

// Routes
require('./routes').applyRoutes(server, '/');
require('./routes/echo').applyRoutes(server, '/echo');

module.exports = server;